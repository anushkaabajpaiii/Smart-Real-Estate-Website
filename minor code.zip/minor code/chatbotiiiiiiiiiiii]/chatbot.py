import requests
from sentence_transformers import SentenceTransformer
import numpy as np
import faiss
import docx

# 🧠 Load semantic model
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# 📄 Load and chunk FAQ from DOCX
def extract_faq_chunks(doc_path):
    doc = docx.Document(doc_path)
    text_chunks = []
    buffer = ""
    for para in doc.paragraphs:
        line = para.text.strip()
        if line.startswith("Q:"):
            if buffer:
                text_chunks.append(buffer.strip())
            buffer = line
        elif line.startswith("A:"):
            buffer += " " + line
        else:
            if buffer:
                buffer += " " + line
    if buffer:
        text_chunks.append(buffer.strip())
    return text_chunks

# 🧱 Create vector index
def create_faiss_index(text_chunks):
    embeddings = embedding_model.encode(text_chunks)
    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(np.array(embeddings))
    return index, embeddings

# 🔍 Semantic search
def search(query, text_chunks, index):
    query_vec = embedding_model.encode([query])
    top_k = 3
    D, I = index.search(np.array(query_vec), top_k)
    return [text_chunks[i] for i in I[0]]

# 🤖 Ask Mistral via HF API
def ask_mistral(question, context, hf_api_key):
    url = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.1"
    headers = {"Authorization": f"Bearer {hf_api_key}"}
    
    prompt = f"""Answer the user's real estate question based on the provided context.
Context:
{context}

Question: {question}
Answer:"""
    
    payload = {
        "inputs": prompt,
        "parameters": {
            "max_new_tokens": 300,
            "temperature": 0.3
        }
    }
    
    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        return response.json()[0]["generated_text"].split("Answer:")[-1].strip()
    else:
        print("Error:", response.text)
        return "Sorry, something went wrong."

# 🧪 Put it all together
if _name_ == "_main_":
    HF_API_KEY = "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"
    doc_path = "C:\\Users\\KIIT0001\\Downloads\\Real Estate Chatbot.docx 2.docx"
    
    chunks = extract_faq_chunks(doc_path)
    index, _ = create_faiss_index(chunks)
    
    while True:
        user_q = input("Ask a real estate question (or type 'exit'): ")
        if user_q.lower() in ['exit', 'quit']:
            break
        
        top_context = "\n\n".join(search(user_q, chunks, index))
        response = ask_mistral(user_q, top_context, HF_API_KEY)
        print("Bot:", response)